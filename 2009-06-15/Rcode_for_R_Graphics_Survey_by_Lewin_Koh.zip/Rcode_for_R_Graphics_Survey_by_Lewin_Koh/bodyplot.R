  library(gclus)
  data(body)
  percep.lev <- c("Gender", "Age", "Weight", "Height", "WristD", "WristG", "ForearmG", "ElbowD", "BicepG","ShoulderG", "Biacrom", 
                  "ChestDp", "ChestD", "ChestG", "WaistG", "AbdG", "HipG", "Biiliac", "Bitro", "ThighG", "KneeG", 
                  "KneeD", "CalfG", "AnkleD", "AnkleG")
  body <- body[,percep.lev]
  body.long <- stack(body[,-1])
  names(body.long) <- c("value","measurement")
  body.long$measurement <- factor(body.long$measurement,levels=percep.lev[-1])
  body.long$gender <- abs(1-rep(body$Gender,24)) # male=0, female=1
  body.long$group<-factor(rep(c(rep("Overall",3),rep("Arm",5), rep("Torso",7), rep("Pelvis",3), rep("Leg",6)), each=507),
                          levels=rev(c("Overall","Arm", "Torso", "Pelvis","Leg")))


  bplt1 <- bwplot(measurement~log(value)|group,groups=gender,body.long,
         layout=c(1,5),scales=list(y=list(relation='free'),x=list(relation='same')),
         panel=function(x,y,...){
             #browser()
           k <- order(1/unique(as.numeric(y)))
           y <- factor(as.character(y), levels=unique(as.character(y))[k])
           panel.superpose(x,y,...)},
         panel.groups=function(x,y,...){
           grp <- list(...)$group.number
           y <- if(grp>1){y-0.25}else{y+0.25}
           panel.bwplot(x,y,...)},
           ##panel.linejoin(x,y, median, lty=grp, lwd=2, col=grey(.7))
         prepanel=function( x, y, type, subscripts, ...){
          # browser()
           k <- order(1/unique(as.numeric(y)))
           y <- factor(as.character(y), levels=unique(as.character(y))[k])
           prepanel.default.bwplot(x, y, type, ...)}, 
         strip=FALSE, strip.left=TRUE, box.ratio=.5)

  #bod <- NULL
  ##for(i in seq(0,1,by=.25))bod <- cbind(bod,with(body.long,tapply(value,list(measurement,gender),quantile,prob=i)))
  
   bod <- lapply(body[,-1],function(x,g){
                          tst<-wilcox.test(x~I(1-g),conf.int=TRUE)
                          c(tst$conf.int[1],tst$estimate,tst$conf.int[2])},
              body$Gender)
   
  bod <- data.frame(matrix(unlist(bod),nc=3,byrow=TRUE))
  names(bod) <- c("lcl","med","ucl")
  bod$measurment <- factor(percep.lev[-1], levels=percep.lev[-1])
  bod$group<-factor(c(rep("Overall",3),rep("Arm",5), rep("Torso",7), rep("Pelvis",3), rep("Leg",6)),levels=rev(c("Overall","Arm", "Torso", "Pelvis","Leg")))

library(latticeExtra)
 
  bplt2 <- dotplot(measurment~med|group,data=bod, draw.bands=FALSE,
          layout=c(1,5), scales=list(y=list(relation="free")),pch=16,
          prepanel=function(x,y,...){
            k <- order(1/unique(as.numeric(y)))
            y <- factor(as.character(y), levels=unique(as.character(y))[k])
            prepanel.default.bwplot(x, y,...)
          },
          panel=function(x,y,subscripts,...){
            k <- order(1/unique(as.numeric(y)))
            y <- factor(as.character(y), levels=unique(as.character(y))[k])
            panel.linejoin(x,y,col=grey(.7),lwd=2)
            panel.dotplot(x,y,...)
            panel.segments(bod$lcl[subscripts],y,bod$ucl[subscripts],y,lwd=3,
                           col="lightblue")
            panel.points(x,y,...)
            
          },strip=FALSE, strip.left=TRUE, 
           main="Differences between males and females in body measurements",
           xlab = "Median difference", between=list(y=c(0,0,0,1)))


