###################################################
### chunk number 1: setup
###################################################
library(lattice)
library(ggplot2)
library(hexbin)
library(gclus)
library(aplpack)
data(NHANES)
NHANES$Race <- factor(ifelse(NHANES$Race==0,"Afro American", "Caucasian"))
library(gclus)
data(body)
#data(wine)
data(bank)
data(swiss)


###################################################
### chunk number 2: kaleid1
###################################################
p <- ggplot(NHANES, aes(Smoke,BMI)) + geom_jitter(alpha = 0.2) + 
    geom_boxplot(fill = NA, outlier.colour="NA", outlier.size=0,colour="red") +
    facet_grid(~Race)+ opts(title = "BMI by Race and Smoking Status")
print(p)


###################################################
### chunk number 3: kaleid2
###################################################
faces(swiss)
title("")


###################################################
### chunk number 4: kaleid3
###################################################
data(Cars93, package = "MASS") 
cor.Cars93 <- cor(Cars93[, !sapply(Cars93, is.factor)], use = "pair") 
ord <- order.dendrogram(as.dendrogram(hclust(dist(cor.Cars93)))) 
panel.corrgram <- function(x, y, z, subscripts, at, level = 0.9, label = FALSE, ...) { 
    require("ellipse", quietly = TRUE) 
    x <- as.numeric(x)[subscripts] 
    y <- as.numeric(y)[subscripts] 
    z <- as.numeric(z)[subscripts] 
    zcol <- level.colors(z, at = at, ...) 
    for (i in seq(along = z)) { 
        ell <- ellipse(z[i], level = level, npoints = 50, scale = c(.2, .2), centre = c(x[i], y[i])) 
        panel.polygon(ell, col = zcol[i], border = zcol[i], ...) 
    } 
    if (label) panel.text(x = x, y = y, lab = 100 * round(z, 2), cex = 0.8, col = ifelse(z < 0, "white", "black")) 
} 
## Figure 13.5 
print(levelplot(cor.Cars93[ord, ord], at = do.breaks(c(-1.01, 1.01), 20), xlab = NULL, ylab = NULL, colorkey = list(space = "top"), scales = list(x = list(rot = 90)), panel = panel.corrgram, label = TRUE))


###################################################
### chunk number 5: kaleid4
###################################################
densdiag <- function(x, ...)
         {
             yrng <- current.panel.limits()$ylim
             d <- density(x)
             d$y <- with(d, yrng[1] + 0.95 * diff(yrng) * y / max(y) )
             panel.lines(d)
         }
print(hexplom(~NHANES[,c(7,9:14)],colramp=BTY,xbins=20,upper.panel=panel.hexboxplot,
              varname.cex = .5,axis.text.cex=.3,
              diag.panel=function(x,varname,...){ 
                  varname<-sub("\\.","\n",varname)
                  diag.panel.splom(x,varname,...)
              }))



###################################################
### chunk number 6: AnRdiagram
###################################################
  source("Rcode/Rgraphsys.R")


###################################################
### chunk number 7: timings eval=FALSE
###################################################
## times<-list()
## j<-1
## for(i in c(100,1000,10000,100000)){
##     x<-rnorm(i)
##     y<-rnorm(i)
##     times[[j]]<-system.time(plot(x,y))
##     j<-j+1
##     times[[j]]<-system.time(print(xyplot(x~y, alpha=.1)))
##     j<-j+1
## }


###################################################
### chunk number 8: bankdatpc
###################################################
mins <- apply(bank[,-1],2,min)
ranges <- apply(bank[,-1],2,max) - mins
bank.m <- -colpairs(scale(bank[,-1],mins,ranges), pclen)
cparcoord(bank[,-1], order.endlink(bank.m), dmat.color(bank.m),col=c("purple","black")[bank[,"Status"]+1])


###################################################
### chunk number 9: bankdat
###################################################
     # m is a homogeneity measure of each pairwise variable plot
     m <- -colpairs(scale(bank[,-1]), partition.crit,gfun=gave,groups=bank[,1])

     # Color panels by level of m and reorder variables so that
     # pairs with high m are near the diagonal. Panels shown
     # in pink have the highest amount of group homogeneity, as measured by 
     # gave.
     cpairs(bank[,-1],order=order.single(m), panel.colors=dmat.color(m),
     gap=.3,col=c("purple","black")[bank[,"Status"]+1],
     pch=c(5,3)[bank[,"Status"]+1])


###################################################
### chunk number 10: bodyset
###################################################
source("Rcode/bodyplot.R")


###################################################
### chunk number 11: body1
###################################################
  print(bplt1)


###################################################
### chunk number 12: body2
###################################################
  print(bplt2)


###################################################
### chunk number 13: bodyCandy eval=FALSE
###################################################
## library(rimage)
## library(gridBase)
## mm<-read.jpeg("Images/small_male_front_bw.jpg")
## fm<-read.jpeg("Images/small_female_front_bw.jpg")
## pdf("Figs/bodyCandy.pdf", width=10,height=10)
## grid.newpage()
## 
## 
## pushViewport(rvp)
## par(plt=gridPLT(), new=TRUE, ps=8)
## plot(mm)
## popViewport()
## 
## pushViewport(lvp)
## par(plt=gridPLT(), new=TRUE, ps=8)
## plot(fm)
## popViewport()
## 
## pushViewport(cvp)
## print(bplt2,newpage=FALSE)
## popViewport()
## dev.off()


###################################################
### chunk number 14: tvshalpha
###################################################
print(xyplot(Transferin~Hemoglobin,NHANES, xlab="Hemoglobin ug/L", ylab="Transferin ug/L", alpha=.2, cex=.6))


###################################################
### chunk number 15: tvshHex
###################################################
print(hexbinplot(Transferin~Hemoglobin,NHANES, xlab="Hemoglobin ug/L", ylab="Transferin ug/L", xbins=40))


###################################################
### chunk number 16: qikqplot
###################################################
p<-qplot(Transferin,Hemoglobin,data=NHANES, facets=Sex ~ Cancer.Incidence)



###################################################
### chunk number 17: qikqplot2
###################################################
print(p)


###################################################
### chunk number 18: qikqplot3
###################################################
p + geom_point(aes(colour =Cancer.Death ))


###################################################
### chunk number 19: qikqplot4
###################################################
print(p)


###################################################
### chunk number 20: ggplotit
###################################################
p <- ggplot(NHANES, aes(x=Transferin,y=Hemoglobin))
p <- p + geom_point()


###################################################
### chunk number 21: ggplotit2
###################################################
print(p)


###################################################
### chunk number 22: ggplotit3
###################################################
 p <- p + geom_point(aes(colour =Cancer.Death, alpha=.2 )) + facet_wrap(Sex ~ Cancer.Incidence)



###################################################
### chunk number 23: ggplotit4
###################################################
print(p)


